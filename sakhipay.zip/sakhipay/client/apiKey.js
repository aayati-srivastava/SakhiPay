// ✅ Save your OpenAI project API key here securely
const sakhiApiKey = "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";
